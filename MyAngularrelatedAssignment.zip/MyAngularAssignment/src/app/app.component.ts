import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-employeelist></app-employeelist>`
})
export class AppComponent {
  title = 'AngularAssignment';
  name = 'Gupta Akaash';
}
