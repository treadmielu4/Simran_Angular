import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  firstname:string='Tom'
  lastname:string='Hopkins'
  gender:string='Male'
  age:number=20
  isDisabled:boolean=false; 
  name:String=''
  showDetails: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  onClick():void{
    this.isDisabled=!this.isDisabled;
    console.log('Button Clicked');
  }

  toggleDetails(): void {
        this.showDetails = !this.showDetails;
    }
}
